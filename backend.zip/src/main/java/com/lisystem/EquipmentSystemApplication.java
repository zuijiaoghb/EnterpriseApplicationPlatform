package com.lisystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquipmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquipmentSystemApplication.class, args);
	}

}
