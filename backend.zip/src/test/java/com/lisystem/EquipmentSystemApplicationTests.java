package com.lisystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquipmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
